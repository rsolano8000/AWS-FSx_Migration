#!/usr/bin/env bash
set -euo pipefail
TASK_ARN=$1
AWS_REGION=us-east-1

EXEC_ARN=$(aws datasync start-task-execution --task-arn "$TASK_ARN" --region $AWS_REGION --query TaskExecutionArn --output text)

echo "Started: $EXEC_ARN"
while true; do
  STATUS=$(aws datasync describe-task-execution --task-execution-arn $EXEC_ARN --region $AWS_REGION --query Status --output text)
  echo "Status: $STATUS"
  if [[ "$STATUS" == "SUCCESS" ]]; then
    break
  elif [[ "$STATUS" == "ERROR" ]]; then
    exit 2
  fi
  sleep 30
done
