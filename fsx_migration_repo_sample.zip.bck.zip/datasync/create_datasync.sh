#!/usr/bin/env bash
set -euo pipefail
TASK_NAME=$1
SMB_USER=$2
SMB_PASS=$3
CSV_FILE=$4
AWS_REGION=us-east-1

FSX_ARN="arn:aws:fsx:us-east-1:123456789012:file-system/fs-0abc123def4567890"

SOURCE_LOC_ARN=$(aws datasync create-location-smb   --server-hostname "onprem-file1.company.local"   --subdirectory "\\finance"   --user "$SMB_USER"   --password "$SMB_PASS"   --mount-options Version=SMB3   --region $AWS_REGION   --query LocationArn --output text)

DEST_LOC_ARN=$(aws datasync create-location-fsx   --fsx-filesystem-arn "$FSX_ARN"   --subdirectory "/finance"   --security-group-arns "arn:aws:ec2:us-east-1:123456789012:sg/sg-0abc123def4567890"   --region $AWS_REGION   --query LocationArn --output text)

TASK_ARN=$(aws datasync create-task   --source-location-arn "$SOURCE_LOC_ARN"   --destination-location-arn "$DEST_LOC_ARN"   --name "$TASK_NAME"   --options '{"VerifyMode":"POINT_IN_TIME_CONSISTENT","PreserveDeletedFiles":"PRESERVE","PosixPermissions":"PRESERVE"}'   --region $AWS_REGION   --query TaskArn --output text)

echo $TASK_ARN > task_arn.txt
