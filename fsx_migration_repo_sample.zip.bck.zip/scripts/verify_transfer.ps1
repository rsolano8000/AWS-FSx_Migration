param(
  [string]$SourceServer,
  [string]$ShareName,
  [string]$DestUNC
)

Write-Host "Verifying $ShareName migration..."

$src = Invoke-Command -ComputerName $SourceServer -ScriptBlock {
  param($share)
  $items = Get-ChildItem -Path "C:\\Shares\\$share" -Recurse -Force
  [PSCustomObject]@{
    Count = ($items | Measure-Object).Count
    Bytes = ($items | Measure-Object -Property Length -Sum).Sum
  }
} -ArgumentList $ShareName

$destItems = Get-ChildItem -Path $DestUNC -Recurse -Force
$dest = [PSCustomObject]@{
  Count = ($destItems | Measure-Object).Count
  Bytes = ($destItems | Measure-Object -Property Length -Sum).Sum
}

Write-Host "Source count: $($src.Count)  Dest count: $($dest.Count)"
Write-Host "Source size:  $($src.Bytes)  Dest size:  $($dest.Bytes)"
